plugins {
    id("com.android.application")
}
android {
    namespace = "uz.suhbat.twa"
    compileSdk = 34
    defaultConfig {
        applicationId = "uz.suhbat.twa"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
dependencies {
    implementation("com.google.androidbrowserhelper:androidbrowserhelper:2.5.0")
}
